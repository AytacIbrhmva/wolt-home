import React, { useEffect, useState } from 'react';
import {HiOutlineMapPin} from 'react-icons/hi2';
import {IoIosArrowForward} from 'react-icons/io';
import SignIn from './auth/SIgnIn';
import SignUp from './auth/SignUp';


export default function Home() {

  const [inputFocus, setInputFocus] = useState(false);
  
  return (
    <div>
        {/* hero */}
        <div id='hero' className='w-full pt-20 h-[620px] sm:h-[840px]  relative overflow-hidden bg-milk'>
            <div className='flex items-end pb-10 sm:items-center sm:pb-16 md:pb-[200px]  max-w-[1200px] h-full mx-auto px-6'>
                {/* main */}
                <div className='flex flex-col gap-8  z-40 sm:w-[530px] '>
                  <h1 className='text-[52px] lg:text-[60px] font-bold font-ubuntu pr-10 text-white sm:text-neutral-900'>Əla yeməkləri kəşfet və əldə et.</h1>
                  <form>
                    <label className='text-white sm:text-neutral-800 font-medium text-xl'>Çatdırılma ünvanı</label>
                    <div className='h-[46px] lg:h-[52px] relative flex items-center mt-4 sm:mr-10'>
                      <HiOutlineMapPin className='absolute text-neutral-600 text-[25px] ml-3' />
                      <p className={inputFocus ? 'absolute text-gray-500 ml-10 text-[13px] mb-5' : 'absolute text-gray-500 ml-10'}>Çatdırılma ünvanı seç</p>
                      <input 
                        type='text' 
                        className='w-full h-full npm sta pl-10 mr-5 rounded-md transition duration-300 border-2 hover:border-primary focus:border-primary focus:outline focus:outline-primary' 
                         />
                      <button className='bg-primary px-3 h-full font-bold text-white text-[14px] rounded-md transition duration-150 hover:bg-blue-400'>Axtarış</button>
                    </div>
                  </form>
                  <a href='' className='text-white sm:text-neutral-800  font-medium text-[19px] lg:text-[22px] transition duration-300  hover:text-primary'>ya da Bakı şəhərindəki populyar restoranlara baxın</a>
                </div>
                {/* img */}
                <div className='w-[1000px] sm:hidden h-full  -right-[220px] top-12 absolute z-30 bg-cover bg-overlay'></div>
                <div className='w-[1000px] lg:w-full xl:w-[1160px] h-full  -right-[220px] top-12 absolute  bg-cover bg-hero bg-no-repeat'></div>
            </div>
        </div>
        {/* hero end */}

        {/* sign in/up */}
        <div className='py-10'>
          <div className='flex justify-center max-w-[1200px] h-full mx-auto px-6'>
            <SignUp />
            <SignIn />
          </div>
        </div>
  
    </div>
  )
}
